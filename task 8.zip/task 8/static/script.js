document.getElementById("weather-form").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    let city = document.getElementById("city").value;
    
    let response = await fetch(`/weather?city=${city}`);
    let data = await response.json();
    
    let resultDiv = document.getElementById("weather-result");

    if (data.error) {
        resultDiv.innerHTML = `<p class="error">${data.error}</p>`;
    } else {
        resultDiv.innerHTML = `
            <h2>${data.location.name}, ${data.location.country}</h2>
            <img src="${data.current.condition.icon}" alt="Weather Icon">
            <p>Temperature: ${data.current.temp_c}°C</p>
            <p>Condition: ${data.current.condition.text}</p>
            <p>Humidity: ${data.current.humidity}%</p>
            <p>Wind Speed: ${data.current.wind_kph} km/h</p>
        `;
    }
});
