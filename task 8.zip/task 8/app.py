from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

WEATHER_API = "c5696a142d1040d698f210409251603"
WEATHER_API_URL= "https://api.weatherapi.com/v1/current.json"  
@app.route('/', methods=['GET'])
def index():
    weather_info = {}
    par = {
        "key": WEATHER_API, 
        "q": "London"}  
    try:
        response = requests.get(WEATHER_API_URL, params=par)
        response.raise_for_status() 
        weather_info = response.json()
    except requests.exceptions.RequestException as e:
        weather_info = {"error": str(e)}  
    return render_template("index.html", weather = weather_info)
@app.route("/weather", methods=["GET"])
def get_weather():
    city = request.args.get("city", "London")
    par = {
        "key": WEATHER_API, 
        "q": city}
    try:
        response = requests.get(WEATHER_API_URL, params=par)
        response.raise_for_status()
        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)

