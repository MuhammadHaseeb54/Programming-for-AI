from flask import Flask, render_template, request
import requests

app = Flask(__name__)

NEWS_API = "pub_74851deb67a5ca8e80c99ad4e82ad2050cbd4"
NEWS_API_URL = "https://newsdata.io/api/1/latest"
@app.route("/", methods=["GET", "POST"])
def home():
    news_data = {}
    if request.method == "POST": 
        searching = request.form.get("searching", "")
        par = {"apikey": NEWS_API, 
               "q": searching
               }
    else: 
        par = {"apikey": NEWS_API}
    response = requests.get(NEWS_API_URL, params=par)
    if response.status_code == 200:
        news_data = response.json()
    else:
        news_data = {"error": "Please try again later."}
    return render_template("index.html", news = news_data)

if __name__ == "__main__":
    app.run(debug=True)
